# Baguetter - Benchmarks

This folder contains the scripts to replicate our benchmarks results.