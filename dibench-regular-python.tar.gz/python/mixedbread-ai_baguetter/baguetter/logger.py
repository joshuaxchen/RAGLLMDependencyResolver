import logging

LOGGER = logging.getLogger("baguetter")
