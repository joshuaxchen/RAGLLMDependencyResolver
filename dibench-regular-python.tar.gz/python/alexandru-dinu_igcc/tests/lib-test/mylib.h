#ifndef MYLIB_H
#define MYLIB_H

void defined_in_cpp();

#endif // MYLIB_H
