#include <iostream>

#include "mylib.h"

void defined_in_cpp()
{
    std::cout << "defined_in_cpp saying hello." << std::endl;
}
