#ifndef HELLO_H
#define HELLO_H

#include <iostream>

void hello()
{
    std::cout << "Hello, " << std::endl;
}

#endif // HELLO_H

