SQLAlchemy-Searchable
=====================

|Version Status| |Downloads|

Fulltext searchable models for SQLAlchemy. Only supports PostgreSQL


Resources
---------

- `Documentation <https://sqlalchemy-searchable.readthedocs.io/>`_
- `Issue Tracker <http://github.com/falcony-io/sqlalchemy-searchable/issues>`_
- `Code <http://github.com/falcony-io/sqlalchemy-searchable/>`_


.. |Version Status| image:: https://img.shields.io/pypi/v/SQLAlchemy-Searchable.svg
   :target: https://pypi.python.org/pypi/SQLAlchemy-Searchable/
.. |Downloads| image:: https://img.shields.io/pypi/dm/SQLAlchemy-Searchable.svg
   :target: https://pypi.python.org/pypi/SQLAlchemy-Searchable/
