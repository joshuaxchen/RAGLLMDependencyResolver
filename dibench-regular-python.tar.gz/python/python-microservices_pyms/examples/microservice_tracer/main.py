from examples.microservice_requests import ms

app = ms.create_app()

if __name__ == "__main__":
    app.run()
