from pyms.flask.app import Microservice

ms = Microservice(path=__file__)
