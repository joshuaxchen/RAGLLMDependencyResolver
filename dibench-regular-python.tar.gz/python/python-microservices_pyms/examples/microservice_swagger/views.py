def example():
    return {"main": "hello world"}
