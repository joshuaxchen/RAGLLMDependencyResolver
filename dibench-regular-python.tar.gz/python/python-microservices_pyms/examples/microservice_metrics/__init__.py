from pyms.flask.app import Microservice

ms = Microservice()
