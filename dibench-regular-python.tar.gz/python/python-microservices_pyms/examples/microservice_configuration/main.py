from examples.microservice_configuration import ms

app = ms.create_app()

if __name__ == "__main__":
    app.run()
