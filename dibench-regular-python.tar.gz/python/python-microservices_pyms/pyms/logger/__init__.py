"""Init file
"""

from .logger import CustomJsonFormatter

__all__ = [
    "CustomJsonFormatter",
]
