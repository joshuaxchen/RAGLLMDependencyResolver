from .main import Command

__all__ = ["Command"]
