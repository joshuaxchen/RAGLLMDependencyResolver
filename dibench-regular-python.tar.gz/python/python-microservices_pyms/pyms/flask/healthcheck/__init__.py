from .healthcheck import healthcheck_blueprint

__all__ = ["healthcheck_blueprint"]
