__author__ = "Alberto Vara"

__email__ = "a.vara.1986@gmail.com"

__version__ = "2.9.0rc1"
