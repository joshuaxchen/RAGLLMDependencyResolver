Fixes # [refer the issue number]

Changes proposed in this PR:
- [Updated X functionality]
- [Refactor X class]
