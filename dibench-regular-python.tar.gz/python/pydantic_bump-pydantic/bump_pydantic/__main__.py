from bump_pydantic.main import entrypoint

if __name__ == "__main__":
    entrypoint()
