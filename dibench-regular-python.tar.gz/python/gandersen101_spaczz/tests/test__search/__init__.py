"""Tests for search modules."""
