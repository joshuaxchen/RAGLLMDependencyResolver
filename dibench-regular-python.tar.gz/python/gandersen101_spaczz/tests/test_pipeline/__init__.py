"""Tests for pipeline modules."""
