Reference
=========

.. contents::
    :local:
    :backlinks: none


spaczz.matcher
--------------------------

.. automodule:: spaczz.matcher
   :members:


spaczz.pipeline
--------------------------

.. automodule:: spaczz.pipeline
   :members:


spaczz.registry
--------------------------

.. automodule:: spaczz.registry
   :members:


spaczz.customattrs
--------------------------

.. automodule:: spaczz.customattrs
   :members:


spaczz.customtypes
--------------------------

.. automodule:: spaczz.customtypes
   :members:


spaczz.exceptions
--------------------------

.. automodule:: spaczz.exceptions
   :members:
