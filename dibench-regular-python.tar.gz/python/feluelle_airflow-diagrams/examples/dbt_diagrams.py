from diagrams import Diagram
from diagrams.k8s.compute import Pod

with Diagram("dbt", show=False):
    _53f5b59c3f29a1b03b56e47614fd6b52 = Pod("dbt_run")
    
    